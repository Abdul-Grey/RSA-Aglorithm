from math import *

# Functions
#Function to calculate coprime
def coprime(value):
    count = 1;
    for i in range(2,value):
        if gcd(i,value)==1:
            if count<3:
                count=count+1;
                continue;
            return i;

#Function to find Modular Multiplicative Inverse
def mmi(a,base):
    for i in range(2,base):
        if (a*i)%base ==1:
            return i;

#Main execution
def start():
    p = int(input("Enter prime number: "))
    q = int(input("Enter prime number: "))
    n=p*q
    gcd_value =gcd(p-1,q-1)
    phi =int((p-1)*(q-1)/gcd_value)
    e = coprime(phi)
    d = mmi(e,phi)
    return [e,d];
