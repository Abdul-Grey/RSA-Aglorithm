from distutils.core import setup
setup(
        name= 'RSA Program',
        version= '1.0.1',
        py_modules=['rsaprogram'],
        author='Abdul',
        author_email= 'info@rsa.ice.in',
        url='https=//www.github.com/Abdul-Grey',
        description='A simple implementation of RSA Algorithm. The Email id won\'t work'
        )
